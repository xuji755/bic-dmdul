# bic-dmdul 0.1.0 发布包

运行方式：

```sh
tar -xzf bic-dmdul-0.1.0.tar.gz
cd bic-dmdul-0.1.0
./bin/bic-dmdul --help
```

本发布包包含源码、文档、命令行入口、LICENSE 和 NOTICE。
